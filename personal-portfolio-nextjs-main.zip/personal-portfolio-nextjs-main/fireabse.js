import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyBVO_EPGW9Ecurjzq3hTn7UzJN9izv8f2A",
    authDomain: "portfolio-1e3c0.firebaseapp.com",
    databaseURL: "https://portfolio-1e3c0-default-rtdb.firebaseio.com",
    projectId: "portfolio-1e3c0",
    storageBucket: "portfolio-1e3c0.appspot.com",
    messagingSenderId: "648286549385",
    appId: "1:648286549385:web:f5b2c7538e5e1c9bcfdd58",
    measurementId: "G-NB6PCH498W"
};

const app = initializeApp(firebaseConfig);
